a = int(input("Enter a: "))
b = int(input("Enter b: "))
print("Addition:", a+b)