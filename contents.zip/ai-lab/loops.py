numOfTimes = int(input("How many times you want to print 'Hello World' ? "))
# for i in range (0, numOfTimes):
#     print("Hello World")

while numOfTimes > 0 :
    print("Hello World")
    numOfTimes -= 1