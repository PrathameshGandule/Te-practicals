# Te-practicals
***
# This repo contains all the practicals I've done in out TE practical labs
- AI
- CC
- DSBDAL
- WT
